-- Q3.1 How many genes in the gene table have an id_biotype of 23?

 Select COUNT(ID_GENE) from gene where ID_BIOTYPE  = 23;

-- Q3.2 What is the Ensembl Gene ID for the Gene_symbol TTTY2?

 SELECT ENSEMBL_GENE_ID FROM gene WHERE GENE_SYMBOL = 'TTTY2'

-- Q3.3 Give a breakdown of the number of genes for each chromosome.

 SELECT CHROMOSOME, COUNT(ID_GENE)  FROM gene GROUP BY CHROMOSOME;

-- Q3.4 How many Transcripts does the Gene Symbol RAI14 has?

 SELECT count(t.COSMIC_ID_TRANSCRIPT)  FROM gene AS g, transcript AS t 
        WHERE g.GENE_SYMBOL = 'RAI14' AND g.ID_GENE = t.ID_GENE;

-- Q3.5 What is the canonical transcript accession for Ensembl Gene id ENSG00000266960?

SELECT t.ACCESSION  FROM gene AS g, transcript AS t
WHERE t.IS_CANONICAL  = 'y' AND g.ENSEMBL_GENE_ID  = 'ENSG00000266960' AND g.ID_GENE= t.ID_GENE;

-- Q3.6 List the Transcript accessions for the Gene Symbol AK1 with id_biotype 23 and flags
-- gencode_basic

SELECT t.ACCESSION  FROM gene AS g, transcript AS t
WHERE g.ID_BIOTYPE  = '23' AND g.GENE_SYMBOL  = 'AK1' AND t.FLAGS = 'gencode_basic' AND g.ID_GENE = t.ID_GENE;

-- Q3.7 Imagine that we have a table called “some_gene” with only a subset of the gene data. If I want to join the gene table with this table but display all the genes in the result, what kind of join would you do?

-- Solution: If new Table is "some_gene" Table and if we join it with "gene" Table, To get all the genes from the "gene" Table in final result, we will do Right Join. It will get all the genes from "gene" Table and will show NULL values for genes not existing in "some_gene" Table.

-- Q3.8 Imagine that the gene and transcript tables are getting very big and that joining the two tables get slower and slower. What would you do to improve performances?

-- Solution:
--  To improve performance as table size grows, we can do below points:
-- 1.	Use Indexing on Tables which makes loads of performance improvement. Indexing create a quick lookup table for finding records which are searched frequently
-- 2.	Use “Exists” instead of JOINS for queries.
-- 3.	Using Common Table expressions where we create a temporary table with less data by using filters and then using it inside our select queries.
-- 4.	Only Select columns required in Select statements. Instead of Select *.

-- Q3.9 If you want to avoid duplicates in a table, what kind of index would you create?

--  Solution: Apart from Primary Key, we can use UNIQUE Index to avoid duplicates. WE can add multiple columns and add a UNIQUE constraint to them. 
-- Eg we can add UNIQUE Index on ID_GENE and GENE_SYMBOL Columns. This will help in keeping control duplicates in multiple these 2 columns.

-- Q3.10 If you want to make sure that all the id_gene ids in the transcript table exists in the gene table, what kind of index would you create?

-- Solution: We can use UNIQUE index for the purpose. The UNIQUE Index can be added on id_gene column in gene table and then create foreign key reference on id_gene column in Transcript table. This is make sure when we any id_gene is inserted in Transcript table, it is verified from id_gene column in gene table. 
